import os
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from openai import OpenAI

app = FastAPI(title="Basil Study Engine", version="1.0.0")

API_KEY = os.getenv("OPENAI_API_KEY")
ENGINE_TOKEN = os.getenv("ENGINE_TOKEN")
MODEL = os.getenv("OPENAI_MODEL")

client = OpenAI(api_key=API_KEY) if API_KEY else None

class Question(BaseModel):
    question: str = Field(min_length=1, max_length=8000)

@app.get("/")
def home():
    return {"engine": "Basil Study Engine", "status": "online"}

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/solve")
def explain_question(
    data: Question,
    authorization: str | None = Header(default=None),
):
    # This endpoint is for explaining practice questions, not automating
    # answers inside a live school exam or bypassing platform rules.
    if not ENGINE_TOKEN:
        raise HTTPException(status_code=503, detail="Engine token is not configured")
    if authorization != f"Bearer {ENGINE_TOKEN}":
        raise HTTPException(status_code=401, detail="Unauthorized")
    if client is None or not MODEL:
        raise HTTPException(status_code=503, detail="OPENAI_API_KEY or OPENAI_MODEL is not configured")

    try:
        result = client.responses.create(
            model=MODEL,
            instructions=(
                "أنت مساعد تعليمي باللغة العربية. اشرح أسئلة التدريب والمراجعة "
                "خطوة بخطوة، وبيّن الفكرة والقانون وسبب الإجابة. إذا كان السؤال "
                "غامضًا فاطلب توضيحًا. لا تدّعِ أنك متصل بمنصة مدرسية."
            ),
            input=data.question,
        )
        return {"answer": result.output_text}
    except Exception:
        raise HTTPException(status_code=502, detail="The AI service request failed")
